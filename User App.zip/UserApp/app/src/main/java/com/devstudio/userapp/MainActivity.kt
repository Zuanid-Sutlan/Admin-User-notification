package com.devstudio.userapp

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.annotation.RequiresApi
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.devstudio.userapp.ui.theme.UserAppTheme
import com.google.android.gms.tasks.OnCompleteListener
import com.google.firebase.Firebase
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener
import com.google.firebase.database.database
import com.google.firebase.messaging.FirebaseMessaging

class MainActivity : ComponentActivity() {
    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {

            val context = LocalContext.current

            val database = Firebase.database
            val myRef = database.getReference("message")

            UserAppTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    Box(
                        modifier = Modifier.padding(innerPadding),
                        contentAlignment = Alignment.Center
                    ) {

//                        FirebaseMessaging.getInstance().token.addOnCompleteListener { task ->
//                            if (!task.isSuccessful) {
//                                Log.w("TAG", "Fetching FCM registration token failed", task.exception)
//                                return@addOnCompleteListener
//                            }
//
//                            val token = task.result
//
//                            val userId = FirebaseAuth.getInstance().currentUser?.uid
//                            val database = FirebaseDatabase.getInstance().reference
//                            userId?.let {
//                                database.child("users").child(it).child("token").setValue(token)
//                            }
//                        }

                        Column {
                            var text by remember { mutableStateOf("") }

                            Text(modifier = Modifier
                                .padding(16.dp), text = text)
                            Button(modifier = Modifier, onClick = {
                                myRef.addValueEventListener(object : ValueEventListener {
                                    override fun onDataChange(snapshot: DataSnapshot) {
                                        text = snapshot.value.toString()
                                    }

                                    override fun onCancelled(error: DatabaseError) {
                                        text = error.message
                                    }
                                })
                            }) {
                                Text(text = "Get")
                            }

                            Button(onClick = {
                                val intent = Intent(context, FirebaseForegroundService::class.java)
                                context.startForegroundService(intent)
                            }) {
                                Text("Start Foreground Service")
                            }

                            Text(text = "Start the foreground service to get the live notification when the data changes from the " +
                                    "firebase realtime data base even the app is not running in the background you can add data to the " +
                                    "realtime database from the admin app which is along with it.")
                        }
                    }
                }
            }
        }
    }
}

